package com.OnlineMarketplace.OnlineMarketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMarketplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
